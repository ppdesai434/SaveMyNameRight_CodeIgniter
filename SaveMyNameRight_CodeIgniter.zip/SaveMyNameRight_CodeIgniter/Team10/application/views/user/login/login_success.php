<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="page-header">
				<h1>Welcome <?php echo $_SESSION['username']; ?> !</h1>
 			</div>
			 <input type="button" class="btn btn-primary btn-lg btn-block" value="EVENTS" onclick="location.href = '<?= base_url('myEvents') ?>';"/>
			<input type="button" class="btn btn-primary btn-lg btn-block" value="CONFERENCES" onclick="location.href = '<?= base_url('myConferences') ?>';"/>
			<input type="button" class="btn btn-primary btn-lg btn-block" value="ORGANIZATIONS" onclick="location.href = '<?= base_url('myOrganizations') ?>';"/>
			<input type="button" class="btn btn-primary btn-lg btn-block" value="UNIVERSITIES" onclick="location.href = '<?= base_url('myUniversity') ?>';"/>
			<input type="button" class="btn btn-primary btn-lg btn-block" value="COLLEGES" onclick="location.href = '<?= base_url('myColleges') ?>';"/>
			<input type="button" class="btn btn-primary btn-lg btn-block" value="COURSES" onclick="location.href = '<?= base_url('myCourses') ?>';"/>
			
		</div>
	</div><!-- .row -->
</div><!-- .container -->
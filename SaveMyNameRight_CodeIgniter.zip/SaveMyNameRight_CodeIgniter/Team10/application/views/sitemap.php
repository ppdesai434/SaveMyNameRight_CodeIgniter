<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			
			<h1><?=$title?></h1>
			<div class="col-xs-12">
				<ul class="list-group">
					<li class="list-group-item">Events
						<ul class="list-group inner">
							<li class="list-group-item"><a href="<?= base_url('myEvents') ?>">My Events</a></li>
							<li class="list-group-item"><a href="<?= base_url('newEvent') ?>">Create Event</a></li>
							
						</ul>
					</li>
					<li class="list-group-item">Conferences
						<ul class="list-group inner">
							<li class="list-group-item"><a href="<?= base_url('myConference') ?>">My Conferences</a></li>
							<li class="list-group-item"><a href="<?= base_url('newConference') ?>">Create Conference</a></li>
							
						</ul>
					</li>
					<li class="list-group-item">Organizations
						<ul class="list-group inner">
							<li class="list-group-item"><a href="<?= base_url('myOrganizations') ?>">My Organizations</a></li>
							<li class="list-group-item"><a href="<?= base_url('newOrganization') ?>">Create Organization</a></li>
							
						</ul>
					</li>
					
					
					<li class="list-group-item">Universities
						<ul class="list-group inner">
							<li class="list-group-item"><a href="<?= base_url('myUniversity') ?>">My Universities</a></li>
							<li class="list-group-item"><a href="<?= base_url('newUniversity') ?>">Create University</a></li>
							
						</ul>
					</li>
					<li class="list-group-item">Colleges
						<ul class="list-group inner">
							<li class="list-group-item"><a href="<?= base_url('myColleges') ?>">My Colleges</a></li>
							<li class="list-group-item"><a href="<?= base_url('newCollege') ?>">Create College</a></li>
							
						</ul>
					</li>
					<li class="list-group-item">Courses
						<ul class="list-group inner">
							<li class="list-group-item"><a href="<?= base_url('myCourses') ?>">My Courses</a></li>
							<li class="list-group-item"><a href="<?= base_url('newCourse') ?>">Create Course</a></li>
							
						</ul>
					</li>
					<li class="list-group-item"><a href="<?= base_url('logout') ?>">Logout</a></li>
					
					
				</ul>
			</div>

			
			
		</div>
	</div><!-- .row -->
</div><!-- .container -->
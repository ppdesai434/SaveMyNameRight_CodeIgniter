<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="page-header">
				<h1>Welcome <?php echo $_SESSION['username']; ?> !</h1>
 			</div>
			
				
			
		</div>
	</div><!-- .row -->
</div><!-- .container -->
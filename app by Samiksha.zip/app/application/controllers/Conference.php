<?php
class Conference extends CI_Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		$this->load->model('Conf_Model');		
	}

	public function myconference(){
	
	$data['title']='My Conference';
	$data['conf']= $this->Conf_Model->get_conf();
	$data['message']='';
	$this->load->view('header');
	$this->load->view('conference/myConferences', $data);
	$this->load->view('footer');
	}



	public function deleteconference($id=null){
	
	
	$this->conf_model->deleteconference($id);
	$data['conf']= $this->conf_model->get_conf();
	$data['message']='Conference Deleted!';
	$this->load->view('header');
	$this->load->view('conference/myConferences', $data);
	$this->load->view('footer');
	}
}

}
?>
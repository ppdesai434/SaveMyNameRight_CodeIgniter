CONTROLLER:

1) I have made some changes in User.php in contoller so try using my User.php
2) Event.php is my controller that handles all view of event pages.

CONFIG:

1) Made changes according to your config.pgp and add 'Event_model.php' in library of config.php
2) routes.php contains all the possible routes. check it once.

EVENT:

1)contains 2 file for the view. please review it.

MODELS:

1) Event_model contains info about db queries.


